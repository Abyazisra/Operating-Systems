// sortString.cpp
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "No string provided!" << endl;
        return 1;
    }

    string str = argv[1];
    sort(str.begin(), str.end());
    cout << "Sorted string: " << str << endl;

    return 0;
}

