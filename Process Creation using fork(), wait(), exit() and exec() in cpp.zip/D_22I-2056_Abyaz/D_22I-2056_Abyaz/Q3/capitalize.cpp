// capitalize.cpp
#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "No string provided!" << endl;
        return 1;
    }

    string str = argv[1];
    for (char& c : str) {
        c = toupper(c);
    }
    cout << "Capitalized string: " << str << endl;

    return 0;
}

