#include <iostream>
#include <cstring>
#include <algorithm>  
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "No string provided!" << endl;
        return 1;
    }

    string str = argv[1];
    reverse(str.begin(), str.end());  // Now the reverse function will work
    cout << "Reversed string: " << str << endl;

    return 0;
}

