// asciiAdd.cpp
#include <iostream>
#include <cstring>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "No string provided!" << endl;
        return 1;
    }

    string str = argv[1];
    for (char& c : str) {
        c += 2;
    }
    cout << "String after ASCII addition: " << str << endl;

    return 0;
}

