// findLength.cpp
#include <iostream>
using namespace std;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        cerr << "No string provided!" << endl;
        return 1;
    }

    // Using C-style string and for loop to find length
    char* str = argv[1];
    int length = 0;

    // Loop through the string until we hit the null terminator
    for (int i = 0; str[i] != '\0'; i++) {
        length++;
    }

    cout << "Length of string: " << length << endl;

    return 0;
}

