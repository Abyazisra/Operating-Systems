#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>
using namespace std;

void forkAndExec(const char* program, char* const args[]) {
    pid_t pid = fork();

    if (pid < 0) {
        cerr << "Fork failed!" << endl;
        exit(1);
    } else if (pid == 0) {
        // In the child process, execute the program using execvp
        execvp(program, args);
        // If exec fails
        cerr << "Exec failed for " << program << "!" << endl;
        exit(1);
    } else {
        // Parent waits for the child to complete
        wait(NULL);
    }
}

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    // Step 1: Reverse the string
    char* reverseArgs[] = { (char*)"./reverseString", str, NULL };
    forkAndExec("./reverseString", reverseArgs);

    // Step 2: Find the length of the string
    char* lengthArgs[] = { (char*)"./findlength", str, NULL };
    forkAndExec("./findlength", lengthArgs);

    // Step 3: Add 2 to ASCII of each character
    char* asciiArgs[] = { (char*)"./asciiAdd", str, NULL };
    forkAndExec("./asciiAdd", asciiArgs);

    // Step 4: Sort the string
    char* sortArgs[] = { (char*)"./sortString", str, NULL };
    forkAndExec("./sortString", sortArgs);

    // Step 5: Capitalize the string
    char* capitalizeArgs[] = { (char*)"./capitalize", str, NULL };
    forkAndExec("./capitalize", capitalizeArgs);

    return 0;
}

