#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

int main() {
    // Step 1: Fork a child process
    pid_t pid = fork();
    
    if (pid < 0) {
        // Error in fork
        std::cerr << "Fork failed!" << std::endl;
        return 1;
    }

    if (pid == 0) {
        // Step 2: In the child process

        // Open output1.txt for writing, creating it if it doesn't exist
        int fd = open("output1.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            std::cerr << "Failed to open output1.txt" << std::endl;
            return 1;
        }
        
        // Redirect standard output to output1.txt
        dup2(fd, STDOUT_FILENO);
        close(fd);
        
        // Step 3: Execute the ls command
        char* args[] = { (char*)"ls", (char*)"-la", (char*)"/home", NULL };
        execvp(args[0], args);
        
        // If execvp fails
        std::cerr << "Exec failed!" << std::endl;
        return 1;
    } else {
        // Step 4: In the parent process
        wait(NULL); // Wait for the child process to complete

        // Step 5: Set the PATH environment variable
        setenv("PATH", "/home", 1);

        // Step 6: Execute the grep command
        // Note: Use globbing for "*.txt" files; this requires additional libraries or manual handling
        char* grepArgs[] = { (char*)"grep", (char*)"output1.txt", (char*)"/home/*.txt", NULL };
        execvp(grepArgs[0], grepArgs);

        // If execvp fails
        std::cerr << "Exec failed!" << std::endl;
        return 1;
    }

    return 0;
}

