#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <vector>
#include<iostream>

using namespace std;

// Define structure for tree node
struct Node {
    char data;
    Node* left;
    Node* right;

    Node(char val) {
        data = val;
        left = right = NULL;
    }
};

// Function to create the binary tree for ABYAZISRAR
Node* createTree() {
    Node* root = new Node('A');
    root->right = new Node('B');
    root->right->right = new Node('Y');
    root->right->left = new Node('A');
    root->right->left->right = new Node('A');
    root->right->right->left = new Node('I');
    root->right->right->right = new Node('Z');
    
    root->right->right->left->right = new Node('S');
    root->right->right->left->right->left = new Node('R');
    root->right->right->left->right->left->right = new Node('R');
    //root->left = new Node('A');  // Right of 'A'
    return root;
}

// Function to display node information and wait for child processes
int displayNode(Node* node) {
    if (node == NULL) return 0;

    pid_t pid_left = 0, pid_right = 0;
    int left_value = 0, right_value = 0;

    // Fork for left child
    if (node->left != NULL) {
        pid_left = fork();
        if (pid_left == 0) {
            // Child process for left child
            int left_sum = displayNode(node->left);
            cout << "Node " << node->data << ": PPID: " << getppid() << ", PID: " << getpid()
                 << " and ASCII: " << (int)node->data << " My child is " << node->left->data << endl;
                 
            // Return ASCII sum to parent    
            exit(left_sum + (int)node->data); 
        }
    }

    // Fork for right child
    if (node->right != NULL) {
        pid_right = fork();
        
        if (pid_right == 0) {
        
            // Child process for right child
            int right_sum = displayNode(node->right);
            cout << "Node " << node->data << ": PPID: " << getppid() << ", PID: " << getpid()
                 << " and ASCII: " << (int)node->data << " My child is " << node->right->data << endl;
            exit(right_sum + (int)node->data); // Return ASCII sum to parent
        }
    }

    // Parent process waits for children to finish
    if (pid_left > 0) waitpid(pid_left, &left_value, 0);
    if (pid_right > 0) waitpid(pid_right, &right_value, 0);

    // Sum up ASCII values from children
    // Extracting exit value
    return (left_value >> 8) + (right_value >> 8) + (int)node->data; 
}

int main() {
    Node* root = createTree();
    int total_ascii_sum = displayNode(root);

    // Display the final ASCII sum at the root node
    cout << "Final ASCII Sum at Node " << root->data << ": " << total_ascii_sum << endl;

    return 0;
}
